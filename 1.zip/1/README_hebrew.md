# פרויקט כרטיסי ביקור - Bcard

## תיאור כללי
הפרויקט הוא מערכת לניהול כרטיסי ביקור, שנבנתה ב-React עם TypeScript, תוך שימוש ב-Bootstrap לעיצוב, FontAwesome לאייקונים ו-Toastify להודעות מערכת. המשתמשים יכולים להרשם, להתחבר, ליצור, לערוך ולמחוק כרטיסים, לסמן כרטיסים מועדפים, לחפש, ולהשתמש במצב כהה/בהיר. למשתמשים עם הרשאת אדמין יש גם גישה לממשק ניהול (CRM) לניהול משתמשים.

---

## טכנולוגיות עיקריות
- React + TypeScript
- Bootstrap
- FontAwesome
- React-Router
- Toastify
- Formik + Yup
- Axios
- RESTful API

---

## תכונות עיקריות
- 📝 הרשמה והתחברות עם JWT
- 👤 פרופיל משתמש עם עריכה
- 💼 יצירת כרטיסים ע"י משתמשים עסקיים בלבד
- 🧾 עריכת ומחיקת כרטיסים לפי הרשאות
- ❤️ סימון כרטיסים כמועדפים
- 🌙 מצב כהה/בהיר (Dark/Light Mode)
- 🔍 חיפוש כרטיסים לפי טקסט מה-Navbar
- 📍 מפה עם כתובת הכרטיס (Google Maps Embed)
- 🔒 הגנת נתיבים לפי סוג משתמש (User, Business, Admin)
- ⚙️ CRM - מערכת ניהול משתמשים למנהלים

---

## CRM - עמוד ניהול אדמינים
- חיפוש לפי שם/אימייל
- צפייה בפרטים של כל משתמש
- עדכון פרטי משתמשים (כולל שם, טלפון, תמונה)
- מחיקת משתמשים
- שינוי סטטוס עסקי (isBusiness)
- דפדוף בין עמודים 

---

## קבצי פרויקט עיקריים
- pages/
  - HomePage.tsx
  - AboutPage.tsx
  - LoginPage.tsx
  - RegisterPage.tsx
  - MyCardsPage.tsx
  - CreateCardPage.tsx
  - EditCardPage.tsx
  - CardDetailsPage.tsx
  - CRMPage.tsx
- components/
  - Card.tsx
  - Spinner.tsx
  - Navbar.tsx
  - Footer.tsx
- validation/
  - userValidation.ts
  - cardValidation.ts
  - crmValidation.ts
- context/
  - UserContext.tsx
  - DarkModeContext.tsx

---

## הערות חשובות
- 100 CSS ,כל הקוד נכתב עד 200 שורות לכל קובץ לפי ההנחיה
- כל הקריאות לשרת מתבצעות עם Axios וכוללות Token בעת הצורך
- במצב שאין נתונים מוצגים Spinner או הודעות מתאימות
- תמונות פרופיל או כרטיס ברירת מחדל מופיעות אוטומטית אם חסרה כתובת
